<?php //define database connection variables as constant
define('DB_USER', "root"); // database user
define('DB_PASSWORD', ""); // database password
define('DB_DATABASE', "pessdb"); // database name
define('DB_SERVER', "localhost"); // db server
?>